package com.moonscythe;

import java.util.concurrent.ThreadLocalRandom;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** One running Moon Beam: white particle lasers that only hurt the chosen opponent. */
public final class MoonBeam extends BukkitRunnable {
	// ---- Tweak these ----
	static final int DURATION_TICKS = 80;       // 4 seconds
	static final int DAMAGE_INTERVAL = 5;       // damage every 5 ticks
	static final double DAMAGE_PER_HIT = 2.0;   // 16 hits x 2 = 32 damage (16 hearts) total
	static final int LASERS_PER_BURST = 7;
	static final double LASER_RADIUS = 12.0;
	static final double SKY_HEIGHT = 32.0;

	private static final Particle.DustOptions WHITE = new Particle.DustOptions(Color.WHITE, 1.6f);

	private final Player owner;
	private final LivingEntity target;
	private int age = 0;

	public MoonBeam(Player owner, LivingEntity target) {
		this.owner = owner;
		this.target = target;
	}

	@Override
	public void run() {
		if (!target.isValid() || target.isDead() || !owner.isOnline()) {
			cancel();
			return;
		}

		World world = target.getWorld();
		Location center = target.getLocation().add(0, target.getHeight() * 0.5, 0);
		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		if (age == 0) {
			world.playSound(center, Sound.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 4f, 1.8f);
			world.playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 3f, 1.4f);
			world.spawnParticle(Particle.END_ROD, center, 150, 0, 0, 0, 0.9);
		}
		if (age > 0 && age % 10 == 0) {
			world.playSound(center, Sound.BLOCK_BEACON_AMBIENT, SoundCategory.PLAYERS, 3f, 2f);
			world.spawnParticle(Particle.END_ROD, center, 60, 0, 0, 0, 0.7);
		}

		// 1) Moon beam: thick white column from the sky onto the opponent
		for (double y = SKY_HEIGHT; y >= 0; y -= 0.6) {
			double px = center.getX() + rnd.nextGaussian() * 0.12;
			double pz = center.getZ() + rnd.nextGaussian() * 0.12;
			world.spawnParticle(Particle.END_ROD, px, center.getY() + y, pz, 1, 0, 0, 0, 0);
			if (y < 6.0) {
				world.spawnParticle(Particle.DUST, px, center.getY() + y, pz, 2, 0.25, 0, 0.25, 0, WHITE);
			}
		}

		// 2) Lasers from everywhere, all converging on the opponent
		if (age % 2 == 0) {
			for (int i = 0; i < LASERS_PER_BURST; i++) {
				double theta = rnd.nextDouble() * Math.PI * 2;
				double up = rnd.nextDouble() * 1.4 - 0.2;
				double r = LASER_RADIUS * (0.6 + rnd.nextDouble() * 0.4);
				Location origin = center.clone().add(Math.cos(theta) * r, up * r * 0.8, Math.sin(theta) * r);
				drawLine(world, origin, center);
			}
			// Two lasers straight from the player to the opponent
			Location hand = owner.getEyeLocation().add(0, -0.3, 0);
			drawLine(world, hand, center);
			drawLine(world, hand.clone().add(0, 0.4, 0), center);
		}

		// 3) Damage - ONLY the opponent (magic damage ignores armor)
		if (age % DAMAGE_INTERVAL == 0) {
			target.setNoDamageTicks(0);
			MoonScythePlugin.beamDamage = true;
			try {
				DamageSource source = DamageSource.builder(DamageType.MAGIC)
					.withCausingEntity(owner)
					.withDirectEntity(owner)
					.build();
				target.damage(DAMAGE_PER_HIT, source);
			} finally {
				MoonScythePlugin.beamDamage = false;
			}
		}

		age++;
		if (age >= DURATION_TICKS) {
			world.playSound(center, Sound.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 3f, 1.6f);
			world.spawnParticle(Particle.END_ROD, center, 100, 0, 0, 0, 1.0);
			cancel();
		}
	}

	private void drawLine(World world, Location from, Location to) {
		Vector delta = to.toVector().subtract(from.toVector());
		double length = delta.length();
		if (length < 0.001) {
			return;
		}
		Vector step = delta.clone().multiply(0.9 / length);
		int points = (int) (length / 0.9);
		Location p = from.clone();
		for (int i = 0; i <= points; i++) {
			world.spawnParticle(Particle.END_ROD, p, 1, 0, 0, 0, 0);
			world.spawnParticle(Particle.DUST, p, 1, 0.05, 0.05, 0.05, 0, WHITE);
			p.add(step);
		}
	}
}
