package com.moonscythe;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import net.kyori.adventure.text.Component;

public class MoonScythePlugin extends JavaPlugin implements Listener, TabExecutor {
	// ---- Tweak these ----
	private static final int CRITS_NEEDED = 3;
	/** Streak resets this many ticks after the last crit (200 = 10 seconds). */
	private static final long STREAK_TIMEOUT_TICKS = 200;
	/** Strength II = amplifier 1. */
	private static final int STRENGTH_AMPLIFIER = 1;
	private static final int STRENGTH_REFRESH_TICKS = 40;

	/** True while the beam is hurting someone, so it isn't counted as a normal hit. */
	static volatile boolean beamDamage = false;

	private long tickCounter = 0;
	private final Map<UUID, Streak> streaks = new HashMap<>();
	private final Set<UUID> strengthGiven = new HashSet<>();

	private static final class Streak {
		int count = 0;
		long lastCrit = 0;
	}

	@Override
	public void onEnable() {
		MoonScytheItem.init(this);
		getServer().getPluginManager().registerEvents(this, this);
		var cmd = getCommand("moonscythe");
		if (cmd != null) {
			cmd.setExecutor(this);
			cmd.setTabCompleter(this);
		}
		Bukkit.getScheduler().runTaskTimer(this, this::tick, 1L, 1L);
	}

	// ---------------------------------------------------------------- command

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		Player target;
		if (args.length >= 1) {
			target = Bukkit.getPlayerExact(args[0]);
			if (target == null) {
				sender.sendMessage(Component.text("Player not found: " + args[0]));
				return true;
			}
		} else if (sender instanceof Player p) {
			target = p;
		} else {
			sender.sendMessage(Component.text("Usage: /moonscythe <player>"));
			return true;
		}
		var leftover = target.getInventory().addItem(MoonScytheItem.create());
		leftover.values().forEach(i -> target.getWorld().dropItemNaturally(target.getLocation(), i));
		sender.sendMessage(Component.text("Gave the Moon Scythe to " + target.getName() + "."));
		return true;
	}

	@Override
	public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
		if (args.length == 1) {
			String prefix = args[0].toLowerCase();
			return Bukkit.getOnlinePlayers().stream().map(Player::getName)
				.filter(n -> n.toLowerCase().startsWith(prefix)).toList();
		}
		return List.of();
	}

	// ------------------------------------------------------------------- tick

	private void tick() {
		tickCounter++;
		boolean enforceNow = tickCounter % 4 == 0;

		for (Player player : Bukkit.getOnlinePlayers()) {
			if (enforceNow) {
				ItemStack[] contents = player.getInventory().getContents();
				for (int i = 0; i < contents.length; i++) {
					ItemStack item = player.getInventory().getItem(i);
					if (MoonScytheItem.isScythe(item)) {
						MoonScytheItem.enforce(item);
					}
				}
			}

			UUID id = player.getUniqueId();
			if (MoonScytheItem.isScythe(player.getInventory().getItemInMainHand())) {
				player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, STRENGTH_REFRESH_TICKS, STRENGTH_AMPLIFIER, true, false, false));
				strengthGiven.add(id);
			} else if (strengthGiven.remove(id)) {
				PotionEffect effect = player.getPotionEffect(PotionEffectType.STRENGTH);
				// only remove OUR effect, not a real strength potion
				if (effect != null && effect.getAmplifier() == STRENGTH_AMPLIFIER && effect.getDuration() <= STRENGTH_REFRESH_TICKS) {
					player.removePotionEffect(PotionEffectType.STRENGTH);
				}
			}
		}
	}

	// ----------------------------------------------------------------- combat

	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onDamage(EntityDamageByEntityEvent e) {
		if (beamDamage || e.getFinalDamage() <= 0) {
			return;
		}

		// Getting hit back resets the victim's streak
		if (e.getEntity() instanceof Player victim) {
			streaks.remove(victim.getUniqueId());
		}

		if (!(e.getDamager() instanceof Player attacker)
			|| !(e.getEntity() instanceof LivingEntity target)
			|| target == attacker
			|| !MoonScytheItem.isScythe(attacker.getInventory().getItemInMainHand())
			|| !isCrit(e, attacker)) {
			return; // normal hits neither add to nor break the streak
		}

		Streak s = streaks.computeIfAbsent(attacker.getUniqueId(), k -> new Streak());
		if (s.count > 0 && tickCounter - s.lastCrit > STREAK_TIMEOUT_TICKS) {
			s.count = 0;
		}
		s.count++;
		s.lastCrit = tickCounter;

		if (s.count >= CRITS_NEEDED) {
			streaks.remove(attacker.getUniqueId());
			attacker.sendActionBar(Component.text("MOON BEAM!"));
			new MoonBeam(attacker, target).runTaskTimer(this, 1L, 1L);
		} else {
			attacker.sendActionBar(Component.text("Moon charge " + s.count + "/" + CRITS_NEEDED));
		}
	}

	@SuppressWarnings("deprecation")
	private boolean isCrit(EntityDamageByEntityEvent e, Player p) {
		if (e.isCritical()) {
			return true;
		}
		// Fallback with vanilla's crit conditions, in case a smash attack isn't flagged as critical
		return p.getAttackCooldown() > 0.9f
			&& p.getFallDistance() > 0
			&& !p.isOnGround()
			&& !p.isClimbing()
			&& !p.isInWater()
			&& !p.isInsideVehicle()
			&& !p.isSprinting()
			&& !p.hasPotionEffect(PotionEffectType.BLINDNESS);
	}

	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		streaks.remove(e.getPlayer().getUniqueId());
		strengthGiven.remove(e.getPlayer().getUniqueId());
	}

	// -------------------------------------------------------- enchant locking

	@EventHandler
	public void onAnvil(PrepareAnvilEvent e) {
		if (MoonScytheItem.isScythe(e.getInventory().getFirstItem()) || MoonScytheItem.isScythe(e.getInventory().getSecondItem())) {
			e.setResult(null);
		}
	}

	@EventHandler
	public void onGrindstone(PrepareGrindstoneEvent e) {
		if (MoonScytheItem.isScythe(e.getInventory().getUpperItem()) || MoonScytheItem.isScythe(e.getInventory().getLowerItem())) {
			e.setResult(null);
		}
	}

	@EventHandler
	public void onPrepareEnchant(PrepareItemEnchantEvent e) {
		if (MoonScytheItem.isScythe(e.getItem())) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onEnchant(EnchantItemEvent e) {
		if (MoonScytheItem.isScythe(e.getItem())) {
			e.setCancelled(true);
		}
	}
}
