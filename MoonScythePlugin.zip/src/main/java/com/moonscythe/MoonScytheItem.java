package com.moonscythe;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

/**
 * The Moon Scythe is a real MACE with custom data, so smash attacks, fall damage
 * and mace sounds are all vanilla. Players need no client mod or resource pack.
 */
public final class MoonScytheItem {
	private static NamespacedKey key;

	private MoonScytheItem() {}

	public static void init(Plugin plugin) {
		key = new NamespacedKey(plugin, "moon_scythe");
	}

	public static boolean isScythe(ItemStack stack) {
		if (stack == null || stack.getType() != Material.MACE || !stack.hasItemMeta()) {
			return false;
		}
		return stack.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
	}

	public static ItemStack create() {
		ItemStack stack = new ItemStack(Material.MACE);
		ItemMeta meta = stack.getItemMeta();

		meta.displayName(Component.text("Moon Scythe", NamedTextColor.WHITE)
			.decorate(TextDecoration.BOLD)
			.decoration(TextDecoration.ITALIC, false));
		meta.lore(List.of(
			Component.text("Strength II while held", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
			Component.text("3 crits in a row unleash the Moon Beam", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
		));

		// 12 attack damage (1 base + 11) and axe attack speed (4.0 - 3.0 = 1.0)
		meta.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
			NamespacedKey.minecraft("base_attack_damage"), 11.0, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
		meta.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
			NamespacedKey.minecraft("base_attack_speed"), -3.0, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));

		meta.setUnbreakable(true);
		meta.addEnchant(Enchantment.BREACH, 3, true);
		meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);

		stack.setItemMeta(meta);
		return stack;
	}

	/** Forces "Breach III and nothing else", unbreakable. Fixes /enchant, anvils, grindstones etc. */
	public static void enforce(ItemStack stack) {
		Map<Enchantment, Integer> enchants = stack.getEnchantments();
		if (!(enchants.size() == 1 && enchants.getOrDefault(Enchantment.BREACH, 0) == 3)) {
			for (Enchantment e : new ArrayList<>(enchants.keySet())) {
				stack.removeEnchantment(e);
			}
			stack.addUnsafeEnchantment(Enchantment.BREACH, 3);
		}
		ItemMeta meta = stack.getItemMeta();
		if (!meta.isUnbreakable()) {
			meta.setUnbreakable(true);
			stack.setItemMeta(meta);
		}
	}
}
